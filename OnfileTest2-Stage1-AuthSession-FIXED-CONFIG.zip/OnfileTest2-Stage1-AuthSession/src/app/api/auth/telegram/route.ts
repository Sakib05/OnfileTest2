import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { nanoid } from "nanoid";
import { createSession, getSessionCookieOptions, validateTelegramInitData, SESSION_COOKIE_NAME } from "@/lib/auth";

/**
 * Exchanges a freshly-signed Telegram Mini App `initData` payload for a
 * secure, server-issued application session. This is the ONLY place a
 * request's Telegram identity is ever derived from client-supplied data —
 * and only after verifying Telegram's HMAC signature with our bot token.
 */
export async function POST(req: NextRequest) {
  const botToken = process.env.TELEGRAM_BOT_TOKEN;
  if (!botToken) {
    return NextResponse.json(
      { error: "Server is not configured for Telegram authentication (missing TELEGRAM_BOT_TOKEN)." },
      { status: 503 }
    );
  }

  let body: { initData?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  }

  if (!body.initData) {
    return NextResponse.json({ error: "initData is required" }, { status: 400 });
  }

  const result = validateTelegramInitData(body.initData, botToken);
  if (!result.ok) {
    return NextResponse.json({ error: "Invalid Telegram authentication data", reason: result.reason }, { status: 401 });
  }

  const tgUser = result.data.user;
  const telegramId = String(tgUser.id);

  try {
    const [existing] = await db.select().from(users).where(eq(users.telegramId, telegramId));

    let userId: number;
    if (existing) {
      await db
        .update(users)
        .set({
          username: tgUser.username ?? existing.username,
          firstName: tgUser.first_name ?? existing.firstName,
          lastName: tgUser.last_name ?? existing.lastName,
          avatarUrl: tgUser.photo_url ?? existing.avatarUrl,
          language: tgUser.language_code ?? existing.language,
          updatedAt: new Date(),
        })
        .where(eq(users.id, existing.id));
      userId = existing.id;
    } else {
      const [created] = await db
        .insert(users)
        .values({
          telegramId,
          username: tgUser.username,
          firstName: tgUser.first_name,
          lastName: tgUser.last_name,
          avatarUrl: tgUser.photo_url,
          language: tgUser.language_code ?? "en",
          referralCode: nanoid(8).toUpperCase(),
        })
        .returning();
      userId = created.id;
    }

    const { token, expiresAt } = await createSession(userId, req.headers.get("user-agent"));

    const res = NextResponse.json({ ok: true });
    res.cookies.set(SESSION_COOKIE_NAME, token, {
      ...getSessionCookieOptions(),
      expires: expiresAt,
    });
    return res;
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
