# Onfile Test2 — Stage 1: Authentication and Sessions

This is a TEST-ONLY working copy. Do not deploy it to production and do not run database migrations against a production database.

## What changed in this stage
- Added Telegram Mini App `initData` validation and server-issued opaque sessions.
- Stores only the SHA-256 hash of the session token in the `sessions` table.
- Added the initial SQL migration at `drizzle/0001_secure_sessions/migration.sql`.
- Changed Drizzle Kit configuration to read `DATABASE_URL` from the environment instead of using a hard-coded local database URL.

## Before testing
1. Extract this ZIP into a separate folder or a separate test GitHub repository. Do not overwrite your original Onfile project.
2. Copy `.env.example` to `.env.local` for local testing and fill in a TEST database URL and the existing bot's token. Never commit real secrets or send the bot token in chat.
3. Review the database URL carefully; it must point to a disposable/test database, not production.
4. Install dependencies with `npm install`.
5. Run `npm run typecheck` and `npm run build`; fix any errors before proceeding.
6. Only after reviewing the migration and confirming the test database, apply the SQL migration to that test database. Do not run it against production.

## Important limitations
- The auth endpoint is added, but this stage does not yet wire secure session checks into every existing API route or complete channel verification.
- Telegram login must be tested inside the Telegram Mini App with valid `initData`; ordinary browser preview is not sufficient to confirm it works.
- Automated dependency installation, typecheck, build, and live Telegram testing were not completed in the preparation environment. Treat this as an unverified test package until those checks pass.
